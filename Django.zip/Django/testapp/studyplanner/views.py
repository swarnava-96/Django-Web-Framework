from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
## Functions or classes are mapped to urls

def index(response):
    return HttpResponse('Welcome to Swarnavas study time table.')


def monday(request):
    return HttpResponse('Today I am learning Data Science.')

def tuesday(request):
    return HttpResponse('Today I am learning Big Data.')

def weekly_timetable(request,day):
    text=""
    if day=='monday':
        text='Today I am learning Data Science'
    elif day=='tuesday':
        text='Today I am learning Big Data'
    return HttpResponse(text)